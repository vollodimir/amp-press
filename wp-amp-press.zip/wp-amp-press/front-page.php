<?php
/*
Template Name: Home Template
*/

global $woocommerce_on;

get_header(); ?>

      <main>
        <section class="top-banner">
          <div class="top-banner__text">
            <h1>
              <?php amp_check_asf('first_slide_title', 'Celebrate the Life & Memories<br /> of a Loved one') ?>
            </h1>
            <div class="top-banner__description">
              <?php amp_check_asf('first_slide_desc', 'Custom memorial cards that you can personalize') ?>  
            </div>
            <a href="<?php echo $woocommerce_on ? get_permalink( wc_get_page_id( 'shop' ) ) : '#' ?>" class="btn">Start Designing</a>
          </div>
        </section>
        
        <?php 
          // testimonials
          get_template_part( 'template-parts/testimonials'); 

          // our-product
          $params_our = array(
            'title'           => amp_check_asf('our_products_title', 'Browse Our Products', true),
            'description'     => amp_check_asf('our_products_description', 'From memorial products to church stationery, we have what you need. To begin, select a category below. If you need assistance, <br /> please <a href="#">contact us</a>.', true),
            'terms'           => amp_check_asf('our_products_cat_id', 25, true),
            'posts_per_page'  => 6,
          ); 
          get_template_part( 'template-parts/our-product', null, $params_our); 

          // related 
          $params_related = array(
            'title'           => amp_check_asf('other_products_title', 'Other Products', true),
            'description'     => amp_check_asf('other_products_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', true),
            'terms'           => amp_check_asf('other_products_cat_id', 28, true),
            'posts_per_page'  => 4
          );
          get_template_part( 'template-parts/related', null, $params_related); 
        
          // advantages
          get_template_part( 'template-parts/advantages'); ?>
        
        <div class="message message--secondary">
          <div class="container">
            <?php amp_check_asf('mesage_text', '<span>all designs are customizable</span>: add, remove, replace all text and photos with your own') ?>
            
          </div>
        </div>

        <?php 
          //bestsellers
          $params_bestsellers = array(
            'title'           => amp_check_asf('bestsellers_title', 'Check out our bestsellers', true),
            'description'     => amp_check_asf('bestsellers_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. <br /> Nunc purus laoreet nunc, mauris, aliquet sed et est.', true),
            'posts_per_page'  => 4,
          );
          get_template_part( 'template-parts/bestsellers', null, $params_bestsellers); 
       
          // featured
          get_template_part( 'template-parts/featured'); 
          
          // testimonials
          get_template_part( 'template-parts/testimonials'); 

          // discounts
          $params_discounts = array(
            'title'           => amp_check_asf('discounts_title', 'Get discounts, exclusive deals and more', true),
            'description'     => amp_check_asf('discounts_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet at nec laoreet tellus donec in pharetra. Mattis a placerat gravida at pharetra, ultricies facilisi convallis.', true),
          );
          get_template_part( 'template-parts/discounts', null, $params_discounts); 
        ?>
      </main>

<?php get_footer(); ?>