<?php
/**
 * Template part for displaying related
 *
 *    Related 
 *         'taxonomy' => 'product_visibility',
 *         'field'    => 'name',
 *         'terms'    => 'featured', 
 * 
 * 
*/

  if ($args['terms']){
      $tax_query = array(
          "taxonomy" => "product_cat",
          "field"    => "id",
          "terms"    => $args['terms'],
      );
  } else {
      $tax_query = array(
          'taxonomy' => 'product_visibility',
          'field'    => 'name',
          'terms'    => 'featured', 
      );
  }
?> 

  <section class="related">
    <div class="container">
      <div class="heading">
        <div class="heading__title">
          <h2><?php echo $args['title'] ?></h2>
        </div>
        <p class="heading__description">
          <?php echo $args['description'] ?>
        </p>
      </div>
      <div class="related__list">
          <?php
              $param = array(
                  'post_type'       => 'product',
                  'posts_per_page'  => $args['posts_per_page'],
                  "tax_query"       => array($tax_query),
              );

              $loop = new WP_Query( $param );
              if ( $loop->have_posts() ) {
                  while ( $loop->have_posts() ) : $loop->the_post();
                      wc_get_template_part( 'content', 'product-related' );
                  endwhile;
              } else {
                  echo __( 'No products found' );
              }
              wp_reset_postdata();
            ?>
       </div>
    </div>
  </section>