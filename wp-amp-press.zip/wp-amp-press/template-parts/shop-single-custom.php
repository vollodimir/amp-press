<?php
/**
* 
*   Part to shop item 
*/
?> 
  <section class="single-custom">
    <h2 class="single-custom__title"><?php amp_check_asf('customization_options_title', 'Customization options') ?></h2>
    <h3 class="single-custom__option"><?php amp_check_asf('option_1', '<span>Option 1:</span> Customize yourself') ?></h3>
    <div class="single-custom__steps">
      <div class="step">
        <div class="step__name">Step 1</div>
        <div class="step__title"><?php amp_check_asf('option1_step1_title', 'Customize Online') ?></div>
      </div>
      <div class="single-custom__arrow">
        <img src="<?php bloginfo('template_url'); ?>/assets/img/icon/custom-arrow-right.svg" alt="Next Step" />
      </div>
      <div class="step">
        <div class="step__name">Step 2</div>
        <div class="step__title"><?php amp_check_asf('option1_step2_title', 'We Print & Ship') ?></div>
      </div>
    </div>

    <h3 class="single-custom__option"><?php amp_check_asf('option_1', '<span>Option 2:</span> We customize for you') ?></h3>
    <div class="single-custom__steps single-custom__steps--small">
      <div class="step step--small">
        <div class="step__name">Step 1</div>
        <div class="step__title"><?php amp_check_asf('option2_step1_title', 'Place Order') ?></div>
        <div class="step__description">
          <?php amp_check_asf('option2_step1_description', 'and<br /> checkout') ?>
        </div>
      </div>
      <div class="step step--small">
        <div class="step__name">Step 2</div>
        <div class="step__title"><?php amp_check_asf('option2_step2_title', 'Upload OR Email') ?></div>
        <div class="step__description"><?php amp_check_asf('option2_step2_description', 'photos<br />& text') ?></div>
      </div>
      <div class="step step--small">
        <div class="step__name">Step 3</div>
        <div class="step__title"><?php amp_check_asf('option2_step3_title', 'We Customize') ?></div>
        <div class="step__description"><?php amp_check_asf('option2_step3_description', 'and email you <br />a proof') ?></div>
      </div>
      <div class="step step--small">
        <div class="step__name">Step 4</div>
        <div class="step__title"><?php amp_check_asf('option2_step4_title', 'You Approve') ?></div>
        <div class="step__description"><?php amp_check_asf('option2_step4_description', 'we print <br />& ship') ?></div>
      </div>
    </div>
  </section> 