<?php
/**
 * Template part for displaying testimonials
 *
 */
?>

  <section class="faqs">
    <div class="container">
      <div class="heading">
        <div class="heading__title">
          <h2><?php echo $args['title'] ?></h2>
        </div>
        <p class="heading__description">
          <?php echo $args['description'] ?>
        </p>
      </div>
      <div class="faqs__list">
        <?php
            $param = array(
              'post_type'      => 'faqs',
              'posts_per_page' => 6,
            );
            $loop = new WP_Query($param);
            while ( $loop->have_posts() ) {
              $loop->the_post();
              ?>
            <a href="<?php echo get_permalink() ?>">
              <div class="faq">
                <div class="faq__img">
                    <?php echo get_the_excerpt(); ?>
                </div>
                <div class="faq__title"><?php the_title(); ?></div>
              </div>
            </a>
          <?php }
              wp_reset_postdata(); // reset the query
        ?>
      </div>
    </div>
  </section>

