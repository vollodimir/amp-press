<?php
/**
 * Template part for displaying discounts form
 *
*/
global $woocommerce_on;
?>
        <section class="advantages">
          <div class="advantages__bg"></div>
          <div class="container">
            <div class="advantages__list">
              <?php
                      $param = array(
                        'post_type'      => 'advantages',
                        'posts_per_page' => 4,
                      );
                      $loop = new WP_Query($param);
                      while ( $loop->have_posts() ) {
                        $loop->the_post();
                        ?>
                        <div class="advantage">
                          <div class="advantage__img">
                            <img src="<?php
                                          if(get_the_post_thumbnail_url()){
                                            the_post_thumbnail_url();
                                            }               
                                        ?>" alt="">
                          </div>
                          <div>
                            <h3 class="advantage__title"><?php the_title(); ?></h3>
                            <p class="advantage__description">
                              <?php the_content(); ?>
                            </p>
                          </div>
                        </div>
                <?php } ?>
            </div>
            <a class="btn" href="<?php echo $woocommerce_on ? get_permalink( wc_get_page_id( 'shop' ) ) : '#' ?>">product catalog</a>
          </div>
        </section>