<?php
/**
 * Template part for displaying related
 *
 * 
*/
?>


  <div class="message message--secondary">
    <div class="container">
      <?php echo $args['text'] ?>
    </div>
  </div>