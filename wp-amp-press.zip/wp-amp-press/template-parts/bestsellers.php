<?php
/**
 * Template part for displaying bestsellers 
 * (sort => popularyty)
 *
*/
global $woocommerce_on;
?> 
  <section class="bestsellers">
    <div class="container">
      <div class="heading">
        <div class="heading__title">
          <h2><?php echo $args['title'] ?></h2>
        </div>
        <p class="heading__description">
          <?php echo $args['description'] ?>
        </p>
      </div>
      <div class="bestsellers__list">
            <?php
              $param = array(
                  'post_type'       => 'product',
                  'posts_per_page'  => $args['posts_per_page'],
                  'orderby'         => 'popularity',
                  'order'           => 'desc'
              );

              $loop = new WP_Query( $param );
              if ( $loop->have_posts() ) {
                  while ( $loop->have_posts() ) : $loop->the_post();
                      wc_get_template_part( 'content', 'product-bestsellers' );
                  endwhile;
              } else {
                  echo __( 'No products found' );
              }
              wp_reset_postdata();
            ?>
      </div>
      <a href="<?php echo $woocommerce_on ? get_permalink( wc_get_page_id( 'shop' ) ) : '#' ?>" class="btn btn--secondary">more designs</a>
    </div>
  </section>