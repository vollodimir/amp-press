<?php
/**
 * Template part for displaying discounts form
 *
*/
?>
        <section class="discounts">
          <div class="container">
            <h2 class="discounts__title"><?php echo $args['title'] ?></h2>
            <p class="discounts__description">
            <?php echo $args['description'] ?>
            </p>

            <?php if (function_exists('newsletter_form')) {
                      newsletter_form('1');
                  } else { ?>
                        <form>
                          <div class="discounts__row">
                            <input type="email" placeholder="Email address" required />
                            <button class="btn">submit</button>
                          </div>
                        </form>
            <?php } ?>
          </div>
        </section>