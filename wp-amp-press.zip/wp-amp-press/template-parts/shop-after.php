<?php
/**
 
 * 
*/




  // advantages dark
  get_template_part('template-parts/advantages', 'dark'); 

  // related
  $params_related = array(
    'title'           => amp_check_asf('related_products','Related Products', true),
    'description'     => amp_check_asf('related_products_desc','Lorem ipsum dolor sit amet, consectetur adipiscing elit.', true),
    //'terms'           => 'other-products',
    'posts_per_page'  => 4
  );
  get_template_part( 'template-parts/related', null, $params_related); 

  //FAQ
  $params_faqs = array(
    'title'           => amp_check_asf('faq_title','Frequently Asked Questions', true),
    'description'     => amp_check_asf('faq_description','Lorem ipsum dolor sit amet, consectetur adipiscing elit <a href="#">Contact us</a>.', true),
  );
  get_template_part( 'template-parts/faqs', null, $params_faqs); 

  // discounts
  $params_discounts = array(
    'title'           => amp_check_asf('discounts_title', 'Get discounts, exclusive deals and more', true),
    'description'     => amp_check_asf('discounts_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet at nec laoreet tellus donec in pharetra. Mattis a placerat gravida at pharetra, ultricies facilisi convallis.', true),
  );
  get_template_part( 'template-parts/discounts', null, $params_discounts); 

  
?> 

 