<?php
/**
 * Template part for displaying featured
 *
*/

?>  

    <section class="featured">
      <div class="container">
          <?php
              $tax_query = array(
                  'taxonomy' => 'product_visibility',
                  'field'    => 'name',
                  'terms'    => 'featured', 
              ); 
              $param = array(
                  'post_type'       => 'product',
                  'posts_per_page'  => 1,
                  "tax_query"       => array($tax_query),
              );

              $loop = new WP_Query( $param );
              if ( $loop->have_posts() ) {
                  while ( $loop->have_posts() ) { 
                    $loop->the_post();
                    ?>
                        <div class="featured__body">
                          <div class="featured__img">
                            <img src="<?php
                                          if(get_the_post_thumbnail_url()){
                                            the_post_thumbnail_url();
                                            } else {
                                              echo bloginfo('template_url') . '/assets/img/featured-1.jpg';
                                            }               
                                        ?>" alt="<?php the_title(); ?>" />
                          </div>
                          <div class="featured__text">
                            <h3 class="featured__subtitle">Featured Product</h3>
                            <h2 class="featured__title">
                            <?php the_title(); ?>
                            </h2>
                            <p class="featured__description">
                              <?php echo get_the_excerpt() ?>
                            </p>
                            <a href="<?php echo get_permalink() ?>" class="btn">create now</a>
                          </div>
                        </div>
                    <?php
                  }
              } else {
                  echo __( 'No products found' );
              }
              wp_reset_postdata();
            ?>
       
      </div>
    </section>