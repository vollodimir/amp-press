<?php
/**
 * Template part for displaying related
 *
*/

?> 

  <section class="our-product">
    <div class="our-product__body">
      <div class="container">
        <div class="heading">
          <div class="heading__title">
            <h2><?php echo $args['title'] ?></h2>
          </div>
          <p class="heading__description">
            <?php echo $args['description'] ?>
          </p>
        </div>
        <div class="our-product__list">
            <?php
              $param = array(
                  'post_type'       => 'product',
                  'posts_per_page'  => $args['posts_per_page'],
                  "tax_query"       => array(
                                          array(
                                            "taxonomy" => "product_cat",
                                            "field"    => "id",
                                            "terms" => $args['terms'],
                                          )
                                        ),
              );

              $loop = new WP_Query( $param );
              if ( $loop->have_posts() ) {
                  while ( $loop->have_posts() ) : $loop->the_post();
                      wc_get_template_part( 'content', 'product-our' );
                  endwhile;
              } else {
                echo $args['terms'];
                  echo __( 'No products found' );
              }
              wp_reset_postdata();
            ?>
        </div>
      </div>
    </div>
  </section>