<?php
/**
 * Template part for displaying testimonials
 *
 */
?>
  <section class="testimonials">
    <div class="container">
      <div class="testimonials__body">
          <?php
              $args = array(
                'post_type'      => 'testimonials',
                'posts_per_page' => -1,
              );
              $loop = new WP_Query($args);
              while ( $loop->have_posts() ) {
                $loop->the_post();
                ?>
                <div class="testimony">
                  <div class="testimony__body">
                    <p class="testimony__autor"><?php the_title(); ?></p>
                    <p class="testimony__text">“<?php echo get_the_content(); ?>”</p>
                  </div>
                </div>
          <?php }
                wp_reset_postdata(); // reset the query
                ?>
      </div>
    </div>
  </section>