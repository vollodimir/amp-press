<?php
/**
 * Shop sidebar
 * 
 */ 

 if ( ! is_active_sidebar( 'shop_sidebar' ) ) { 

    $args = array(
      'taxonomy' => 'product_cat',
      'hide_empty' => true,
      'hierarchical' => true,
      'parent'   =>0,
    );
    $curent_cat = get_queried_object();
    $product_cats = get_terms( $args );
    $count = count($product_cats);

    if ( $count > 0 ){
      foreach ( $product_cats as $product_cat ) {
        $args_sub = array(
          'taxonomy' => 'product_cat',
          'hide_empty' => true,
          'parent'   => $product_cat->term_id,
        );
        $product_subcats = get_terms( $args_sub );
        $count_sub = count($product_subcats);

          echo '<details>';
          echo '<summary><h3>';
          echo  $product_cat->name;
          echo  '</h3></summary>';

          if( $product_subcats > 0 ){
            echo '<ul class="categories__list">';

            foreach ( $product_subcats as $product_subcat ) {
              if($product_subcat -> term_id == $curent_cat -> term_id) {
                  $active_class = 'class="categories__list--active"';
                } else {
                  $active_class = '';
              }
              echo '<li '. $active_class .'>';
                echo '<a href="'. get_category_link($product_subcat -> term_id) .'">';
                  echo  $product_subcat->name;
                echo  '</a>';
              echo  '</li>';
            }

            echo '</ul>';
          }

          echo  '</details>';
      }
    }
    
} else {
  dynamic_sidebar('shop_sidebar');
}

?>