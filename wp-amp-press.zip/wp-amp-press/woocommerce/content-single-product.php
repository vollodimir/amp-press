<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 * 
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
//do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}

?>

  <section class="shop shop--single">
    <header class="shop__header">
      <h1 class="shop__title"><? echo $product->post->post_title; ?></h1>
    </header>

	  <article class="shop-single">

      <?php
        $attachment_ids = $product->get_gallery_image_ids(); 
        if($attachment_ids) {?>

            <section class="single-galery">
              <div class="single-galery__active-img">
                <div class="single-galery__active-list">
                  <?php
                    foreach( $attachment_ids as $attachment_id ) {
                      echo '<div><img src="'.$image_link = wp_get_attachment_url( $attachment_id ).'" alt="" /></div>';
                    }
                  ?>
                </div>
                <div class="single-galery__zoom">
                  <img src="<?php bloginfo('template_url'); ?>/assets/img/icon/zoom.svg" alt="Zoom" /> 
                </div>
              </div>

              <div class="popup">
                <div class="popup__body">
                <div class="popup__bg">
                  <div class="popup__slider">
                    <?php
                      foreach( $attachment_ids as $attachment_id ) {
                        echo '<div><img src="'.$image_link = wp_get_attachment_url( $attachment_id ).'" alt="" /></div>';
                        }
                      ?>
                  </div>
                  <div class="popup__close">Close</div>
                </div>
                </div>
              </div>

              <div class="single-galery__list">
                <?php
                  $attachment_ids = $product->get_gallery_image_ids();
                  foreach( $attachment_ids as $attachment_id ) {
                    echo '<div class="single-galery__slide">';
                      echo '<div class="single-galery__item">';
                        echo '<img src="'.$image_link = wp_get_attachment_url( $attachment_id ).'" alt="" />';
                      echo '</div>';
                    echo '</div>';
                  }
                ?>
              </div>
            </section>

        <?php }
      ?>

      <section class="single-options">
        <?php
        /**
         * Hook: woocommerce_single_product_summary.
         *
         * @hooked woocommerce_template_single_title - 5
         * @hooked woocommerce_template_single_rating - 10
         * @hooked woocommerce_template_single_price - 10
         * @hooked woocommerce_template_single_excerpt - 20
         * @hooked woocommerce_template_single_add_to_cart - 30
         * @hooked woocommerce_template_single_meta - 40 remove
         * @hooked woocommerce_template_single_sharing - 50
         * @hooked WC_Structured_Data::generate_product_data() - 60
         */
        do_action( 'woocommerce_single_product_summary' );
        ?> 
      </section>

      <?php get_template_part( 'template-parts/shop-single-custom', null, $params_discounts); ?>

      <section class="single-details">
        <div class="tabs">
          <input type="radio" name="tabs" id="tabone" checked="checked" />
          <label for="tabone">
            <?php amp_check_asf('order_details_title', 'Order details:') ?>
          </label>
          <div class="tabs__item">
            <?php $product->list_attributes(); ?>
            <div class="tabs__item--description">
              <?php  the_content(); ?>
            </div>
            <div class="tabs__faq">
              <?php
                $param = array(
                  'post_type'      => 'faqs',
                    'posts_per_page'  => 1,
                );
                $loop = new WP_Query( $param );
                if ( $loop->have_posts() ) {
                    while ( $loop->have_posts() ) { 
                      $loop->the_post();
                      ?>
                        <h3>FAQ – <?php the_title(); ?></h3>
                        <?php the_content(''); ?>
                      <?php
                    }
                } else {
                    echo __( 'No FAQs found' );
                }
                wp_reset_postdata();
              ?>
              <a class="tabs__faq--link" href="/faqs">FAQ <?php echo get_term_by(  'name', 'faqs', 'my_custom_taxonomy' ) ?> </a>
            </div>
          </div>

          <input type="radio" name="tabs" id="tabtwo" />
          <label for="tabtwo"><?php amp_check_asf('amp_guidelines_title', 'AMP cards Design Guidelines:') ?></label>
          <div class="tabs__item">
            <?php amp_check_asf('amp_guidelines_text', 'AMP cards Design Guidelines some text') ?>
          </div>
        </div>
      </section>

	  </article>
  </section>

