<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */
//add--------------------------------------------------------------------------
//home
	defined( 'ABSPATH' ) || exit;

	global $product;

	// Ensure visibility.
	if ( empty( $product ) || ! $product->is_visible() ) {
		return;
	}
	?>

	<div class="bestseller">
		<div class="bestseller__img">
			<div class="bestseller__hover">
				<a href="<?php echo get_permalink() ?>" class="btn">create now</a>
			</div>
			<img src="<?php
			if(has_post_thumbnail()){
				echo get_the_post_thumbnail_url($product->get_id()); 
			} else {
				bloginfo('template_url').'/assets/img/product-1.png';
			}
			?>" alt="<?php the_title(); ?>" />
		</div>
		<div class="bestseller__text">
			<a href="<?php echo get_permalink() ?>"><?php the_title(); ?></a>
		</div>
		<div class="bestseller__heart">
			<input type="checkbox" name="heart" />
			<svg
			width="16"
			height="16"
			viewBox="0 0 16 16"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
				>
			<path
				d="M7.99998 14.3078C7.7722 14.3078 7.5526 14.2297 7.38146 14.0877C6.73509 13.5525 6.11193 13.0496 5.56212 12.606L5.55932 12.6037C3.94738 11.3029 2.55542 10.1796 1.58691 9.07301C0.504272 7.83594 0 6.66303 0 5.38169C0 4.13676 0.450805 2.98824 1.26928 2.14754C2.09753 1.2969 3.234 0.828403 4.46972 0.828403C5.3933 0.828403 6.23912 1.1049 6.98363 1.65015C7.35936 1.92537 7.69994 2.26221 7.99998 2.6551C8.30016 2.26221 8.64061 1.92537 9.01646 1.65015C9.76097 1.1049 10.6068 0.828403 11.5304 0.828403C12.766 0.828403 13.9026 1.2969 14.7308 2.14754C15.5493 2.98824 16 4.13676 16 5.38169C16 6.66303 15.4958 7.83594 14.4132 9.07289C13.4447 10.1796 12.0528 11.3028 10.4411 12.6034C9.89036 13.0478 9.26622 13.5515 8.61839 14.088C8.44737 14.2297 8.22765 14.3078 7.99998 14.3078Z"
			/>
			<path
				d="M7.99998 14.3078C7.7722 14.3078 7.5526 14.2297 7.38146 14.0877C6.73509 13.5525 6.11193 13.0496 5.56212 12.606L5.55932 12.6036C3.94738 11.3029 2.55542 10.1796 1.58691 9.07301C0.504271 7.83594 0 6.66303 0 5.38169C0 4.13676 0.450805 2.98824 1.26928 2.14754C2.09753 1.2969 3.234 0.828403 4.46972 0.828403C5.3933 0.828403 6.23912 1.1049 6.98363 1.65015C7.35936 1.92537 7.69994 2.26221 7.99998 2.6551C8.30016 2.26221 8.64061 1.92537 9.01646 1.65015C9.76097 1.1049 10.6068 0.828403 11.5304 0.828403C12.766 0.828403 13.9026 1.2969 14.7308 2.14754C15.5493 2.98824 16 4.13676 16 5.38169C16 6.66303 15.4958 7.83594 14.4132 9.07289C13.4447 10.1796 12.0528 11.3028 10.4411 12.6034C9.89036 13.0478 9.26622 13.5515 8.61839 14.088C8.44737 14.2297 8.22765 14.3078 7.99998 14.3078V14.3078ZM4.46972 1.71592C3.49889 1.71592 2.60705 2.08281 1.95825 2.74908C1.2998 3.42541 0.937132 4.36032 0.937132 5.38169C0.937132 6.45935 1.3601 7.42316 2.30847 8.50672C3.22509 9.5541 4.58849 10.6543 6.1671 11.9282L6.17003 11.9306C6.72191 12.3759 7.34752 12.8808 7.99864 13.42C8.65367 12.8798 9.28026 12.3741 9.83323 11.928C11.4117 10.6541 12.775 9.5541 13.6916 8.50672C14.6399 7.42316 15.0628 6.45935 15.0628 5.38169C15.0628 4.36032 14.7002 3.42541 14.0417 2.74908C13.393 2.08281 12.5011 1.71592 11.5304 1.71592C10.8192 1.71592 10.1662 1.93 9.5897 2.35214C9.07591 2.72851 8.718 3.20428 8.50816 3.53719C8.40025 3.70838 8.21031 3.81056 7.99998 3.81056C7.78966 3.81056 7.59972 3.70838 7.49181 3.53719C7.28209 3.20428 6.92418 2.72851 6.41027 2.35214C5.83373 1.93 5.18078 1.71592 4.46972 1.71592V1.71592Z"
				fill="#ED2D38"
			/>
			</svg>
		</div>
	</div>

