<?php
    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }

	add_action( 'wp_enqueue_scripts', function () {
        //styles
           wp_enqueue_style( 'slick-theme', get_template_directory_uri() . '/assets/css/slick-theme.css' );
           wp_enqueue_style( 'slick', get_template_directory_uri() . '/assets/css/slick.css' );
           wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.min.css' );
        //scripts
           wp_enqueue_script( 'slick', get_template_directory_uri() . '/assets/js/slick.min.js', array('jquery'), false, true );
           wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.min.js', array('jquery'), false, true );
       });
    
?>