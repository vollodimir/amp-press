<?php

	// Woocommerce support
	function woocommerce_support() {
		add_theme_support('woocommerce');
	}
	add_action( 'after_setup_theme', 'woocommerce_support' );

	//  sidebar
	function amp_register_shop_sidebars() {
	    register_sidebar(
	        array(
	            'id' => 'shop_sidebar', 
	            'name' => 'Shop sidebar',
	            'description' => 'Default all product categories',
	            'before_widget' => '<details>',
	            'after_widget' => '</details>',
	            'before_title' => '<summary><h3>',
	            'after_title' => '</h3></summary>'
	        )
	    );
	}
	add_action( 'widgets_init', 'amp_register_shop_sidebars' );

 
	//Remove summarys
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
	remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );


	//Remove default WooCommerce wrapper.
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

	if ( ! function_exists( 'dev_woocommerce_wrapper_before' ) ) {
		function dev_woocommerce_wrapper_before() {
			if(! is_single()){
				?>
				<main class="shop-container">
					<div class="container">
				<?php
			}else{
				?>
				<main class="shop-container shop-container--single">
					<div class="container">
				<?php
			}

		}
	}
	add_action( 'woocommerce_before_main_content', 'dev_woocommerce_wrapper_before' );

	if ( ! function_exists( 'dev_woocommerce_wrapper_after' ) ) {

		function dev_woocommerce_wrapper_after() {
			?>
						</div>
					</main>
			<?php
		}
	}
	add_action( 'woocommerce_after_main_content', 'dev_woocommerce_wrapper_after' );


	// myaccount page
	function account_login_out_link()
	{
		if (is_user_logged_in()) { 
			echo get_permalink(wc_get_page_id('myaccount'));
		} elseif (!is_user_logged_in()) { 
			echo get_permalink(wc_get_page_id('myaccount'));
		}
	}


	// Product per page
	$default_posts_per_page = 12;
	add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$default_posts_per_page.';' ));
	// Show all button
	if(isset( $_GET['showall']) ){ 
		add_filter( 'loop_shop_per_page', create_function( '$cols', 'return -1;' ) ); 
	} else {
		add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$default_posts_per_page.';' ) );
	}


	// Script to hide default price after show current
	wc_enqueue_js( "      
		$(document).on('found_variation', 'form.cart', function( event, variation ) {   
			if(variation.price_html) {
				$('#first-price').hide();
			}
		});
	" );