<?php

    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }
 
    // check asf plugin activate 
	function amp_check_asf($fielf_asf, $echo_text, $to_params=false) {
		if (function_exists('get_field')){
			$home_id = get_option('page_on_front');

			if (get_field($fielf_asf, $home_id)){
				$page_id = $home_id;
			} else {
				$page_id = false;
			}
		}

		if(function_exists('get_field') && get_field($fielf_asf, $page_id)){
			if($to_params){
				return get_field($fielf_asf, $page_id); 
			} else {
				echo get_field($fielf_asf, $page_id);
			}
		 } else {
			if($to_params){
				return $echo_text; 
			} else {
				echo $echo_text;
			}
		}
	}


	// cleer number telephone
	function amp_tel_only_number ($field, $echo_text){
		$str = amp_check_asf($field, $echo_text, true);
		$pattern = '/[^0-9]/';

		return preg_replace($pattern, "", $str);
	}
	

	// old widgets ON
	add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
	add_filter( 'use_widgets_block_editor', '__return_false' );
	

	// Enable SVG download
	add_filter( 'upload_mimes', 'svg_upload_allow' );

	function svg_upload_allow( $mimes ) {
		$mimes['svg']  = 'image/svg+xml';
		return $mimes;
	}

	add_filter( 'wp_check_filetype_and_ext', 'fix_svg_mime_type', 10, 5 );

	function fix_svg_mime_type( $data, $file, $filename, $mimes, $real_mime = '' ){

		if( version_compare( $GLOBALS['wp_version'], '5.1.0', '>=' ) ){
			$dosvg = in_array( $real_mime, [ 'image/svg', 'image/svg+xml' ] );
		}
		else {
			$dosvg = ( '.svg' === strtolower( substr( $filename, -4 ) ) );
		}

		if( $dosvg ){

			if( current_user_can('manage_options') ){

				$data['ext']  = 'svg';
				$data['type'] = 'image/svg+xml';
			} else {
				$data['ext']  = false;
				$data['type'] = false;
			}
		}
		return $data;
	}

	add_filter( 'wp_prepare_attachment_for_js', 'show_svg_in_media_library' );

	function show_svg_in_media_library( $response ) {
		if ( $response['mime'] === 'image/svg+xml' ) {
			$response['image'] = [
				'src' => $response['url'],
			];
		}
		return $response;
	}
	// Enable SVG download END
	
?>