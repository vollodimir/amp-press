<?php
    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }

	// testimonials
	function testimonials_create_post_type() {
		register_post_type( 'testimonials', array(
			'labels' => array(
				'menu_name' => 'Testimonials',
				'singular_name' => 'Testimonial',
				'add_new' => 'Add testimonial'
			),
			'menu_position' => 7,
			'has_archive' => true,
			'public' => true,
			'menu_icon' => 'dashicons-format-chat',
			'supports' => array('title', 'editor', 'post-formats'),
		) );
	}
	add_action( 'init', 'testimonials_create_post_type' );


	// advantages
	function advantages_create_post_type() {
		register_post_type( 'advantages', array(
			'labels' => array(
				'menu_name' => 'Advantages',
				'singular_name' => 'Advantage',
				'add_new' => 'Add advantage'
			),
			'menu_position' => 6,
			'public' => true,
			'menu_icon' => 'dashicons-editor-table',
			'supports' => array('title', 'editor', 'thumbnail',  'post-formats')
		) );
	}
	add_action( 'init', 'advantages_create_post_type' );

	
	// FAQs
	function faqs_create_post_type() {
		register_post_type( 'faqs', array(
			'has_archive' => true,
			'labels' => array(
				'menu_name' => 'FAQs',
				'singular_name' => 'FAQ',
				'add_new' => 'Add FAQ'
			),
			'menu_position' => 8,
			'public' => true,
			'menu_icon' => 'dashicons-universal-access',
			'supports' => array('title', 'editor', 'excerpt', 'post-formats')
		) );
	}
	add_action( 'init', 'faqs_create_post_type' );



?>