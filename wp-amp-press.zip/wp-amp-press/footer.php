      <footer class="footer">
        <div class="footer__widgets container">
          <div class="footer__left">
            <div class="logo">
                <?php 
                      if( get_custom_logo() ) {
                          the_custom_logo();
                        } else {
                          ?><a href="/"><img src="<?php bloginfo('template_url'); ?>/assets/img/logo.png" alt="Logo" /></a><?php
                        }
                  ?>
            </div>
            <?php amp_footer_privacy (); ?>
          </div>
          <nav>
            <?php amp_footer_menu (); ?>

            <div class="footer__right">
            <a href="tel:<?php echo amp_tel_only_number('telephone', '(800) 763 6964') ?>" class="tel"><?php amp_check_asf('telephone', '(800) 763 6964') ?></a>
              
              <div class="socials">
                <h4 class="socials__title">Get Social</h4>
                <div class="socials__list">
                  <?php 
                      $home_id = get_option('page_on_front');
                      if(function_exists('get_field') && get_field('instagram_link', $home_id)) {
                      ?>
                          <div class="socials__item socials__item--inst">
                            <a href="<?php amp_check_asf('instagram_link', '#') ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img/icon/socials_inst.svg" alt="" /> </a>
                          </div>
                  <?php } ?>

                  <?php 
                      if(function_exists('get_field') && get_field('fb_link', $home_id)) {
                      ?>
                          <div class="socials__item socials__item--fb">
                            <a href="<?php amp_check_asf('fb_link', '#') ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img/icon/socials_fb.svg" alt="" /> </a>
                          </div>
                  <?php } ?>

                  <?php 
                      if(function_exists('get_field') &&  get_field('linkedin_link', $home_id)) {
                      ?>
                          <div class="socials__item socials__item--in">
                            <a href="<?php amp_check_asf('linkedin_link', '#') ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img/icon/socials_in.svg" alt="" /> </a>
                          </div>
                  <?php } ?>

                  <?php 
                      if(function_exists('get_field') && get_field('twitter_link', $home_id)) {
                      ?>
                          <div class="socials__item socials__item--twi">
                            <a href="<?php amp_check_asf('twitter_link', '#') ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img/icon/socials_twi.svg" alt="" /> </a>
                          </div>
                  <?php }  ?>

                </div>
              </div>
            </div>
          </nav>
        </div>
        <div class="footer__copy-bg">
          <div class="container">
            <div class="footer__copyrights">
              <div class="footer__copy-text">© 2023 <a href="#"><?php bloginfo('name'); ?></a></div>
              <div class="footer__development">
                Dallas WordPress Development: <a href="#">Web Loft Designs</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
    <?php wp_footer(); ?>
  </body>
</html>