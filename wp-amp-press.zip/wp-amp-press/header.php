<?php 
  global $woocommerce_on;
  ?>

<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0" />
    <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>
    <div class="wrapper">
      <header class="header">
        <div class="header__body">
          <div class="message">
            <?php amp_check_asf('head_alert_msg', '<img src="/wp-content/themes/wp-amp-press/assets/img/icon/covid-19.svg" alt="COVID-19" /> COVID-19 Notice: We are still open for business. All orders are shipping on time.');  ?>
          </div> 
          <div class="header__container">
            <input class="header__input" type="checkbox" />
            <div class="header__lines"></div>
            <div class="logo">
                <?php 
                    if(get_custom_logo()) {
                        the_custom_logo();
                      } else {
                        ?><a href="/"><img src="<?php bloginfo('template_url'); ?>/assets/img/logo.png" alt="Logo" /></a><?php
                      }
                ?>
            </div>
            <nav class="header__navigation">
              <div class="header__top-nav">
                <div class="header__delivery"><?php amp_check_asf('header_shipping', 'Free Shipping Over $50') ?></div>
                <a href="tel:<?php echo amp_tel_only_number('telephone', '(800) 763 6964') ?>" class="tel"><?php amp_check_asf('telephone', '(800) 763 6964') ?></a>
                <div class="header__icons">
                  <a href="<?php $woocommerce_on ? account_login_out_link() : '#' ?>" class="header__user"></a>
                  <a href="<?php echo $woocommerce_on ? esc_url( wc_get_cart_url()) : '#'; ?>" class="header__cart"></a>
                </div>
              </div>
              <?php amp_header_menu (); ?>
            </nav>
          </div>
        </div>
      </header>